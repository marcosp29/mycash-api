package org.mycash.web.dto.error;

public class ApiSubError {

}
