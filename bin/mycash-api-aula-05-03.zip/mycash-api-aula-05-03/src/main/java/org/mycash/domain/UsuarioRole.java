package org.mycash.domain;

public enum UsuarioRole {

	ROLE_ADMIN,
	ROLE_USER
	
}