package org.mycash.domain;

public enum LancamentoTipo {

	DESPESA,
	RECEITA
	
}
